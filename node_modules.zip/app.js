const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const pdf = require('html-pdf');

const app = express();
const PORT = process.env.PORT || 8888;

// Middleware to parse JSON in request body
app.use(cors());
app.use(express.json());

// API route to generate PDF from HTML content
app.post('/generate-pdf', (req, res) => {
  const htmlContent = req.body.html;

  // Create PDF options
  const pdfOptions = { format: 'Letter' }; // You can adjust the format as needed

  // Convert HTML to PDF
  pdf.create(htmlContent, pdfOptions).toBuffer((err, buffer) => {
    if (err) {
      res.status(500).json({ error: 'Failed to generate PDF' });
      return;
    }

    // Send the PDF as response
    res.setHeader('Content-Type', 'application/pdf');
    res.send(buffer);
  });
});

// Route to show that API is running
app.get('/', (req, res) => {
  res.send('API is running!');
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
